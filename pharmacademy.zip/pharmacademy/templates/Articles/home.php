<!-- File: templates/Articles/index.php -->
<div>
    
    <?= $this->element('elearn_navbar'); ?>
    <?= $this->element('elearn_carousel'); ?>
    <?= $this->element('elearn_services'); ?>
    <?= $this->element('elearn_about'); ?>
    <?= $this->element('elearn_categories'); ?>
    <?= $this->element('elearn_courses'); ?>
    <?= $this->element('elearn_team'); ?>
    <?= $this->element('elearn_testimonial'); ?>
    <?= $this->element('elearn_footer'); ?>

</div>

